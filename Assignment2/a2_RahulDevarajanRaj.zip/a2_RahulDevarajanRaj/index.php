<?php
// Rahul Devarajan Raj (300342528)

require "lib.php";
$degree = 2;  // the degree of an expression. Just change this degree and the whole program works based on the 
$expr_simplified_str ="";
class Term{
    public $coefficient;
    public $exponent;
    public function __construct($coefficient, $exponent)
    {
        $this->coefficient = $coefficient;
        $this->exponent = $exponent;
    }   
}

display_html_head("Algebraic Expressions");



if($_SERVER['REQUEST_METHOD'] == 'POST') {

    display_form($_POST['degree']);
    $degree = $_POST['degree'];
    $expr = new Expression($degree);    
    $expr->generate();
    display_expression("The Generated Expression: ", $expr->stringify());
    display_expression("Its Simplified Version: ", Expression::simplify($expr)->stringify()); 

   
    
}
else{
    display_form($degree);
}



display_html_foot();

function display_form($default_degree){

print "Select the degree of the expression: <br />";

print <<<_FORM
<form action="index.php" method="post">
<label name="degree"><b>Degree:</b></label>
<input type="text" name="degree" value="$default_degree" />
<input type="submit" value="Generate" />
</form>
_FORM;
}

function display_expression($caption, $expr_str)
{
    print <<<_EXPR
    <div>
    <label>$caption</label><span>$expr_str</span><br />
    </div>
    _EXPR;
}



// stringifies only one term
function stringify_term($exponent)
{
    $term = "";
    if ($exponent == 1)
        $term .= "x";
    else if ($exponent > 1)
        $term .= "x" . "<sup>$exponent</sup>";
    return $term;
}

class Expression {
    const coefficient_min = -20;
    const coefficient_max = 20;
    //terms is an array of Term objects
    public $terms;
    public int $degree;
    public int $num_of_terms;
    public function __construct($degree)
    {
        $this->degree = $degree;
        $this->num_of_terms = 2 * $degree + 3;   
        $this->terms = [];   

    }

    public function generate()
    {
        $excluded = [0];
        do {
            $this->terms = [];
            for ($i = 0; $i < $this->num_of_terms ; $i++) {
                do {                    
                    $coefficient = rand(self::coefficient_min, self::coefficient_max);
                } while (in_array($coefficient, $excluded));
                $exponent = rand(0, $this->degree);
                $this->terms[] = new Term($coefficient, $exponent);
            }
        } while (!$this->meets_requirements());  // re-generate expression if it does not meet the requirement
        return $this->terms;
    }

    public function stringify()
    {
        $expression = "";
        // strigify the first term as it is different that the other terms- the sign (- or +) is connected to the number, also if there is only 
        // one term, no + or - sign is needed after 
        if ($this->terms[0]->coefficient != 0) {
            if ($this->terms[0]->exponent == 0) {
                $expression .= $this->terms[0]->coefficient;
            } else if ($this->terms[0]->coefficient == 1) {
                $expression .= stringify_term($this->terms[0]->exponent);;
            } else if ($this->terms[0]->coefficient == -1) {
                $expression .= "-" . stringify_term($this->terms[0]->exponent);;
            } else {
                $expression .= $this->terms[0]->coefficient . stringify_term($this->terms[0]->exponent);
            }
        }
        // strigify the rest of the terms
        for ($i = 1; $i < count($this->terms); $i++) {
            if ($this->terms[$i]->coefficient == 0) {
                continue;
            } else if ($this->terms[$i]->coefficient < 0) {
                $expression .= " - ";
            } else if ($this->terms[$i]->coefficient > 0) {
                $expression .= " + ";
            }
            if ($this->terms[$i]->exponent == 0) {
                $expression .= abs($this->terms[$i]->coefficient);
            } else if (abs($this->terms[$i]->coefficient) == 1) {
                $expression .= stringify_term($this->terms[$i]->exponent);;
            } else {
                $expression .= abs($this->terms[$i]->coefficient) . stringify_term($this->terms[$i]->exponent);
            }
        }
        return $expression;
    }

    public function meets_requirements()
    {$isValid = false;
        for ($deg = $this->degree; $deg >= 0; $deg--) {
            $isValid = false;
            $counter = 0;
            for ($i = 0; $i < $this->num_of_terms; $i++) {
                if ($this->terms[$i]->exponent == $deg) {
                    $counter++;
                    if ($counter == 2) {
                        $isValid = true;
                        break;
                    }
                }
            }
            if (!$isValid) {
                break;
            }
        }
        return $isValid;
    }

    public static function simplify(Expression $expr){
        
        $result = new Expression($expr->degree);

        for($i=$expr->degree; $i>=0; $i--){
           $sum = 0;
              for($j=0; $j<$expr->num_of_terms; $j++){
                if($expr->terms[$j]->exponent == $i){
                     $sum += $expr->terms[$j]->coefficient;
                }
              }
              if($sum != 0){
                $result->terms[] = new Term($sum, $i);
            }
        }
        $result->num_of_terms = count($result->terms);
        return $result;
    }
   
}