<?php
require 'lib.php';
$degree = rand(0, 3);
$num_of_terms = 2 * $degree + 3;

display_html_head("Algebraic Expressions");
display_expression($degree);
form_input();
display_html_foot();


function generate_expression($degree)
{
    global $num_of_terms;
    $terms = array();
    for ($i = 0; $i < $num_of_terms; $i++) {
        $coeff = 0;
        while ($coeff == 0) {
            $coeff = rand(-20, 20);
        }
        $terms[0][$i] = $coeff;
        $terms[1][$i] = rand(0, $degree);
    }
    return $terms;
}

function meets_requirements($terms, $degree)
{
    global $num_of_terms;
    for ($i = $degree; $i >= 0; $i--) {
        $count = 0;
        for ($j = 0; $j < $num_of_terms; $j++) {
            if ($terms[1][$j] == $i) {
                $count++;
            }
        }
        if ($count < 2) {
            return false;
        }
    }
    return true;
}

function print_expression($terms)
{
    global $num_of_terms;
    for ($i = 0; $i < $num_of_terms; $i++) {
        if ($terms[0][$i] > 0 && $i != 0)
            print "+";
        else if ($terms[0][$i] < 0)
            print "-";


        if (abs($terms[0][$i]) == 1 && $terms[1][$i] != 0) {
            print "";
        } else
            print abs($terms[0][$i]);

        if ($terms[1][$i] == 1) {
            print "x";
        } else if ($terms[1][$i] == 0) {
            print "";
        } else
            print "x<sup>" . $terms[1][$i] . "</sup>";
    }
}



function display_expression($degree)
{
    $isOk = false;
    while (!$isOk) {
        $terms = generate_expression($degree);
        $isOk = meets_requirements($terms, $degree);
    }
    print_expression($terms);
}
