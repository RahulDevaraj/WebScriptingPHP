<?php

function display_html_head($title)
{
    print <<<EOT
    <!DOCTYPE html>
    <html>
    <head>
    <title>$title</title>
    </head>
    <body>
    EOT;
}

function form_input()
{
    print <<<EOT
    &nbsp;= 
     <form style="display: inline-block">    
    <input type="input" name="answer"/>   
    <input type="submit" value="Check"/>   
    </form>
   
    EOT;
}

function display_html_foot()
{
    print <<<EOT
    </body>
    </html>
    EOT;
}
